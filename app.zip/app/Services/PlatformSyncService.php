<?php

namespace App\Services;

use App\Models\Listing;
use App\Models\Product;
use App\Models\PlatformAccount;

class PlatformSyncService
{
    /**
     * Sync products from an e-commerce platform
     * NOTE: This uses MOCK DATA for thesis demo.
     */
    public function syncProducts(PlatformAccount $account)
    {
        // ---------- MOCK PLATFORM RESPONSE -------------
        $fetchedProducts = [
            [
                'platform_product_id' => 'P0001',
                'title' => 'Wireless Mouse',
                'price' => 199,
                'stock' => 15,
            ],
            [
                'platform_product_id' => 'P0002',
                'title' => 'Gaming Keyboard',
                'price' => 549,
                'stock' => 8,
            ]
        ];
        // ------------------------------------------------

        foreach ($fetchedProducts as $item) {

            // Check if product already exists
            $product = Product::firstOrCreate(
                [
                    'user_id' => $account->user_id,
                    'title'   => $item['title'],
                ],
                [
                    'cost_price'     => rand(50, 200), // random mock
                    'desired_margin' => 20,
                ]
            );

            // Create/update listing
            Listing::updateOrCreate(
                [
                    'product_id' => $product->id,
                    'platform_account_id' => $account->id,
                    'platform_product_id' => $item['platform_product_id'],
                ],
                [
                    'price' => $item['price'],
                    'stock' => $item['stock'],
                    'status' => 'active',
                    'synced_at' => now(),
                ]
            );
        }

        // Update last sync time
        $account->update(['last_synced_at' => now()]);
    }
}
