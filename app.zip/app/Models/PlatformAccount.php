<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PlatformAccount extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'platform',
        'account_name',
        'access_token',
        'refresh_token',
        'additional_data',
        'last_synced_at',
    ];

    protected $casts = [
        'additional_data' => 'array',
        'last_synced_at' => 'datetime',
    ];

    // RELATIONSHIPS
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function listings()
    {
        return $this->hasMany(Listing::class);
    }

    public function syncJobs()
    {
        return $this->hasMany(SyncJob::class);
    }
}
