<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Listing extends Model
{
    use HasFactory;

    protected $fillable = [
        'product_id',
        'platform_account_id',
        'platform_product_id',
        'price',
        'stock',
        'status',
        'synced_at',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'synced_at' => 'datetime',
    ];

    // RELATIONSHIPS
    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function platformAccount()
    {
        return $this->belongsTo(PlatformAccount::class);
    }

    public function priceHistory()
    {
        return $this->hasMany(PriceHistory::class);
    }

    public function recommendation()
    {
        return $this->hasOne(Recommendation::class);
    }
}
