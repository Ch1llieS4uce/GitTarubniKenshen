<?php

namespace App\Jobs;

use App\Models\PlatformAccount;
use App\Services\PlatformSyncService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SyncController implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * The platform account id to sync.
     *
     * @var int
     */
    public int $platformAccountId;

    /**
     * Create a new job instance.
     *
     * @param  int  $platformAccountId
     * @return void
     */
    public function __construct(int $platformAccountId)
    {
        $this->platformAccountId = $platformAccountId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(): void
    {
        $account = PlatformAccount::find($this->platformAccountId);

        if (! $account) {
            // account removed or invalid — nothing to do
            return;
        }

        $service = new PlatformSyncService();
        $service->syncProducts($account);
    }
}
