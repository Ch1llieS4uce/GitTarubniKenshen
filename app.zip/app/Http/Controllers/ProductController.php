<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use App\Http\Requests\Products\ProductRequest;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        return Product::where('user_id', $request->user()->id)->get();
    }

    public function store(ProductRequest $request)
    {
        $product = Product::create([
            'user_id'        => $request->user()->id,
            'title'          => $request->title,
            'sku'            => $request->sku,
            'description'    => $request->description,
            'main_image'     => $request->main_image,
            'cost_price'     => $request->cost_price,
            'desired_margin' => $request->desired_margin,
            'attributes'     => $request->attributes,
        ]);

        return response()->json($product, 201);
    }

    public function show($id)
    {
        return Product::findOrFail($id);
    }

    public function update(ProductRequest $request, $id)
    {
        $product = Product::findOrFail($id);

        $product->update($request->validated());

        return response()->json($product);
    }

    public function destroy($id)
    {
        Product::findOrFail($id)->delete();

        return response()->json(['message' => 'Product deleted']);
    }
}
