<?php

namespace App\Http\Controllers;

use App\Models\Listing;
use Illuminate\Http\Request;

class ListingController extends Controller
{
    public function show($id)
    {
        return Listing::with(['product', 'platformAccount'])->findOrFail($id);
    }

    public function priceHistory($id)
    {
        $listing = Listing::findOrFail($id);

        return $listing->priceHistory()->latest()->get();
    }
}
