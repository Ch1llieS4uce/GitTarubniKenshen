<?php

namespace App\Http\Controllers;

use App\Models\Listing;
use Illuminate\Support\Facades\Http;

class RecommendationController extends Controller
{
    public function getRecommendation($listingId)
    {
        $listing = Listing::with('product')->findOrFail($listingId);

        $payload = [
            'title'           => $listing->product->title,
            'cost_price'      => $listing->product->cost_price,
            'desired_margin'  => $listing->product->desired_margin,
            'current_price'   => $listing->price,
        ];

        // Example AI service URL — replace with your actual ML server
        $AI_URL = "http://127.0.0.1:5000/predict";

        $response = Http::post($AI_URL, $payload);

        if (!$response->successful()) {
            return response()->json([
                'error' => 'AI service unavailable',
                'details' => $response->body()
            ], 503);
        }

        return $response->json();
    }
}
