<?php

namespace App\Jobs;

use App\Models\PlatformAccount;
use App\Services\PlatformSyncService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SyncPlatformProductsJob implements ShouldQueue
{
    use InteractsWithQueue, Queueable, SerializesModels;

    public PlatformAccount $platformAccount;

    public function __construct(PlatformAccount $platformAccount)
    {
        // Serialize model ID only (safe for queues)
        $this->platformAccount = $platformAccount;
    }

    public function handle(): void
    {
        $service = new PlatformSyncService();
        $service->syncProducts($this->platformAccount);
    }
}
